# Legacy four-marker synthetic inputs

These are 400 artificial participants and four markers retained from the older
engineering example. The current two-step workflow uses examples/synthetic400.
Extract this archive at the software root; examples/sparse400 contains the
legacy inputs. No real participant data or algorithm code are included.

For the old matched-reference workflow, explicitly supply --af-policy matched.
For 0k omit the reference AF and background arguments. This old fixture does not
supply an independent background set for the new default batch workflow.
Keep W=1, declare individual-case-control sampling, and use fresh outputs.
