# WtGxE synthetic400 two-step input example

This is artificial engineering input only: 400 participants, four target markers,
220 independent background draws and four deliberately invalid/QC markers.
The background and targets use disjoint marker IDs and the same subject order.
Paired identical genotypes agree with the supplied 200 two-person GRM components.
The reference AN is 8000 per marker. One background reference row has reversed
alleles; the importer must align it. Use --maf .01 --mac 20. Four bad markers
exercise missing, monomorphic, low-MAC and absent-reference handling.

The W column deliberately equals 1. Keep it with an explicit individual-case-
control declaration for this engineering example. Do not replace it with a
prevalence borrowed from an unrelated real study. The data are not a simulation
estimate of type one error rate/power, a real participant cohort, or a substitute
for independent background calibration from a study.

From the supplied separately prepared software root:

1. Use background.bed/bim/fam + study.pheno + study.grm + background.afreq
   with --af-target-bim targets.bim --af-background-out background_summary.tsv.
2. Analyze targets.bed/bim/fam with the same study tables/GRM, targets.afreq
   and --af-batch-background background_summary.tsv --out new_result.

The website manual gives complete shell/PowerShell commands. Every output prefix
must be fresh. This archive contains input data and README files only; no WtGxE
source code, executable, mathematical derivation, or software installer.
