# WtGxE synthetic input data

Extract at the root of the separately obtained WtGxE software package. The
current worked example uses examples/synthetic400 for a two-step background
summary export and target analysis. Read that folder's README and the website
manual. The legacy examples/sparse400 input files are retained separately.

This archive has only artificial input data and README files. It contains no
real participants, executable, algorithm source, installer or research manuscript.
